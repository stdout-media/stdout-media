---
layout: post
title: About
path: about
---

Рассказываем последние события в IT, показываем бесконечные новости, учим технологиям.

Мы в социальных сетях:
[Telegram](https://t.me/stdout_media)
[ВКонтакте](https://vk.com/stdout.media)
